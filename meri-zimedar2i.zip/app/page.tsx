"use client"
import { Header } from "@/components/header"
import { Footer } from "@/components/footer"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Input } from "@/components/ui/input"
import Link from "next/link"
import {
  Upload,
  Users,
  Calendar,
  CreditCard,
  UserCheck,
  FileUp,
  LinkIcon,
  CheckCircle,
  ThumbsUp,
  Lock,
  ShieldCheck,
  Server,
} from "lucide-react"
import { useRef, useEffect } from "react"
import { gsap } from "gsap"
import { useGSAP } from '@gsap/react'
import splitType from "split-type"
import { ScrollTrigger } from "gsap/dist/ScrollTrigger"
import SignInForm from "@/components/sign-in-form"

export default function HomePage() {
  // Replace the existing cardRef, overlayRef, contentRef and handlers with this:
  const cardsRef = useRef<HTMLDivElement[]>([])
  const overlaysRef = useRef<HTMLDivElement[]>([])

  useGSAP(() => {
    let splittedText = new splitType(".text-main", { types: 'lines' })
    gsap.from(splittedText.lines, {
      duration: 1,
      opacity: 0,
      y: 100,
      stagger: 0.6,
      ease: 'power4.out',
    })
  })


  // Card hover animation handlers
  const handleCardEnter = (index: number) => {
    if (cardsRef.current[index]) {
      gsap.to(cardsRef.current[index], {
        scale: 1.05,
        boxShadow: "0 10px 25px rgba(0,0,0,0.1)",
        duration: 0.3,
        ease: "power2.out",
      })
    }

    if (overlaysRef.current[index]) {
      gsap.to(overlaysRef.current[index], {
        opacity: 1,
        y: 0,
        duration: 0.3,
        ease: "power2.out",
      })
    }
  }

  const handleCardLeave = (index: number) => {
    if (cardsRef.current[index]) {
      gsap.to(cardsRef.current[index], {
        scale: 1,
        boxShadow: "0 4px 6px rgba(0,0,0,0.05)",
        duration: 0.3,
        ease: "power2.inOut",
      })
    }

    if (overlaysRef.current[index]) {
      gsap.to(overlaysRef.current[index], {
        opacity: 0,
        y: 20,
        duration: 0.5,
        ease: "power2.inOut",
      })
    }
  }

  return (
    <div className="flex min-h-screen flex-col" >
      <Header  />
      <div className="flex-1 " >
        {/* Hero Section */}
        <section data-scroll-section  className="scroll-mt-[100px] relative md:h-[580px] overflow-hidden py-8 md:py-12 ">
          <div
            className="absolute inset-0 bg-cover bg-center z-0"
            style={{ backgroundImage: "url('/img/hero-banner.jpg')" }}
          ></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black/50 to-black/30 z-[1]"></div>
          <div className="container h-full relative z-10 flex items-center justify-center">
            <div className="grid gap-8  lg:grid-cols-2 lg:gap-16 items-center">
              <div className="flex flex-col space-y-6">
                <div className="space-y-4">
                  <h1 className="overflow-hidden text-main text-4xl font-bold text-white tracking-tighter sm:text-5xl md:text-6xl">
                    Secure Your Legacy with Confidence
                  </h1>
                  <p className="text-xl text-muted md:text-2xl">
                    A smart way to safeguard your financial assets and nominee information.
                  </p>
                </div>
                <div className="flex flex-col sm:flex-row gap-3">
                  <Button size="lg" className="font-medium">
                    Get Started
                  </Button>
                  <Button size="lg" variant="outline" className="font-medium">
                    Learn More
                  </Button>
                </div>
                <div className="flex items-center space-x-4 text-sm text-muted">
                  <div className="flex items-center">
                    <CheckCircle className="mr-1 h-4 w-4" />
                    <span>Secure & Encrypted</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="mr-1 h-4 w-4" />
                    <span>Easy to Use</span>
                  </div>
                  <div className="flex items-center">
                    <CheckCircle className="mr-1 h-4 w-4" />
                    <span>24/7 Support</span>
                  </div>
                </div>
              </div>

              {/* Login/Signup Card */}
              <SignInForm />
            </div>
          </div>
          <div className="absolute bottom-0 left-0 right-0 h-24 bg-gradient-to-t from-background to-transparent"></div>
        </section>

        {/* What We Do Section */}
        <section data-scroll-section  id="features" className="scroll-mt-[100px] py-20 bg-background">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl section-title">What We Do?</h2>
              <p className="mt-4 text-xl text-muted-foreground">
                Our platform offers comprehensive solutions for your asset management needs
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4 ">
              {["Asset Upload", "Nominee Management", "Monthly Life Declaration", "Subscription Plans"].map(
                (title, index) => (
                  <Card
                    key={index}
                    className=" shadow-md transition-shadow feature-card overflow-hidden border-[1px]"
                    ref={(el) => {
                      if (el) cardsRef.current[index] = el
                    }}
                    onMouseEnter={() => handleCardEnter(index)}
                    onMouseLeave={() => handleCardLeave(index)}
                  >
                    <CardContent className="pt-6 relative  ">
                      <div className="flex flex-col items-center text-center space-y-4">
                        <div className="p-3 rounded-full bg-primary/10">
                          {index === 0 && <Upload className="h-8 w-8 text-primary" />}
                          {index === 1 && <Users className="h-8 w-8 text-primary" />}
                          {index === 2 && <Calendar className="h-8 w-8 text-primary" />}
                          {index === 3 && <CreditCard className="h-8 w-8 text-primary" />}
                        </div>
                        <h3 className="text-xl font-bold">{title}</h3>
                        <p className="text-muted-foreground">
                          {index === 0 &&
                            "Securely upload and store important documents and financial assets in our encrypted platform."}
                          {index === 1 && "Add and manage nominees who will have access to your assets when needed."}
                          {index === 2 &&
                            "Simple monthly verification process to ensure the security of your account and assets."}
                          {index === 3 &&
                            "Flexible subscription options to meet your specific needs and budget requirements."}
                        </p>
                      </div>

                    </CardContent>
                    <div
                      ref={(el) => {
                        if (el) overlaysRef.current[index] = el
                      }}
                      className="absolute inset-0 bg-primary flex flex-col items-center justify-center text-white opacity-0 translate-y-5 p-4"
                    >
                      <h3 className="text-xl font-bold mb-2">{title}</h3>
                      <p className="text-white/90 text-center">
                        {index === 0 &&
                          "Securely upload and store important documents and financial assets in our encrypted platform."}
                        {index === 1 && "Add and manage nominees who will have access to your assets when needed."}
                        {index === 2 &&
                          "Simple monthly verification process to ensure the security of your account and assets."}
                        {index === 3 &&
                          "Flexible subscription options to meet your specific needs and budget requirements."}
                      </p>
                    </div>
                  </Card>
                ),
              )}
            </div>
          </div>
        </section>

        {/* How It Works Section */}
        <section data-scroll-section  id="how-it-works" className="scroll-mt-[100px] py-20 bg-muted">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl section-title">How We Do?</h2>
              <p className="mt-4 text-xl text-muted-foreground">
                A simple step-by-step process to secure your assets and legacy
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-3 lg:grid-cols-5">
              {[
                {
                  title: "Register & Verify",
                  icon: <UserCheck className="h-8 w-8 text-primary" />,
                  desc: "Create an account and complete the verification process to ensure security.",
                },
                {
                  title: "Upload Your Assets",
                  icon: <FileUp className="h-8 w-8 text-primary" />,
                  desc: "Securely upload important documents and financial information to your account.",
                },
                {
                  title: "Link Nominees",
                  icon: <LinkIcon className="h-8 w-8 text-primary" />,
                  desc: "Add trusted individuals as nominees who will have access to your assets when needed.",
                },
                {
                  title: "Stay Verified Monthly",
                  icon: <CheckCircle className="h-8 w-8 text-primary" />,
                  desc: "Complete a simple monthly verification to maintain the security of your account.",
                },
                {
                  title: "Peace of Mind",
                  icon: <ThumbsUp className="h-8 w-8 text-primary" />,
                  desc: "Rest easy knowing your assets are secure and your legacy is protected for the future.",
                },
              ].map((item, index) => (
                <Card
                  key={index + 5}
                  className="border-none shadow-md transition-shadow feature-card overflow-hidden"
                  ref={(el) => {
                    if (el) cardsRef.current[index + 5] = el
                  }}
                  onMouseEnter={() => handleCardEnter(index + 5)}
                  onMouseLeave={() => handleCardLeave(index + 5)}
                >
                  <CardContent className="pt-6 relative ">
                    <div className="flex flex-col items-center text-center space-y-4">
                      <div className="p-3 rounded-full bg-primary/10">{item.icon}</div>

                      <div className="flex items-center justify-center w-auto p-3 h-8 rounded-full bg-primary text-primary-foreground font-bold">
                        <span className="pr-2">Step</span>{index + 1}

                      </div>
                      <h3 className="text-lg font-bold">{item.title}</h3>

                    </div>

                  </CardContent>
                  <div
                    ref={(el) => {
                      if (el) overlaysRef.current[index + 5] = el
                    }}
                    className="absolute inset-0 bg-primary flex flex-col items-center justify-center text-white opacity-0 translate-y-5 p-4"
                  >
                    <h3 className="text-lg font-bold mb-2">{item.title}</h3>
                    <p className="text-white/90 text-justify text-md">{item.desc}</p>
                  </div>
                </Card>
              ))}
            </div>
          </div>
        </section>

        {/* Why Choose Us Section */}
        <section data-scroll-section  id="why-us" className="scroll-mt-[100px] relative md:h-[580px]  py-20 bg-transparent">
          <div
            className="absolute inset-0 bg-cover bg-center -z-10"
            style={{ backgroundImage: "url('/img/hero-banner.jpg')" }}
          ></div>
          <div className="absolute inset-0 bg-gradient-to-r from-black/60 to-black/30 -z-8"></div>
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold text-white tracking-tighter sm:text-4xl md:text-5xl section-title">
                Why Choose Us
              </h2>
              <p className="mt-4 text-xl text-muted">
                Our platform offers industry-leading security and reliability
              </p>
            </div>

            <div className="grid gap-8 md:grid-cols-2 lg:grid-cols-4">
              {[
                {
                  title: "Data Encryption",
                  icon: <Lock className="h-8 w-8 text-primary" />,
                  desc: "All your data is protected with AES-256 encryption, the industry standard for secure data storage.",
                },
                {
                  title: "Multi-Factor Authentication",
                  icon: <ShieldCheck className="h-8 w-8 text-primary" />,
                  desc: "Enhanced security with multi-factor authentication to prevent unauthorized access to your account.",
                },
                {
                  title: "99.9% Uptime",
                  icon: <Server className="h-8 w-8 text-primary" />,
                  desc: "Our platform ensures 99.9% uptime, giving you reliable access to your assets whenever you need them.",
                },
                {
                  title: "Secure Payment Gateway",
                  icon: <CreditCard className="h-8 w-8 text-primary" />,
                  desc: "All financial transactions are processed through secure, PCI-compliant payment gateways.",
                },
              ].map((item, index) => (
                <Card
                  key={index + 10}
                  className="border-none shadow-md transition-shadow feature-card"
                  ref={(el) => {
                    if (el) cardsRef.current[index + 10] = el
                  }}
                  onMouseEnter={() => handleCardEnter(index + 10)}
                  onMouseLeave={() => handleCardLeave(index + 10)}
                >
                  <CardContent className="pt-6 relative overflow-hidden">
                    <div className="flex flex-col items-center text-center space-y-4">
                      <div className="p-3 rounded-full bg-primary/10">{item.icon}</div>
                      <h3 className="text-xl font-bold">{item.title}</h3>
                      <p className="text-muted-foreground">{item.desc}</p>
                    </div>

                  </CardContent>
                </Card>
              ))}
            </div>
          </div>
        </section>
        {/* FAQ Section */}
        <section data-scroll-section  id="faq" className="scroll-mt-[100px] py-20 bg-background">
          <div className="container">
            <div className="text-center mb-16">
              <h2 className="text-3xl font-bold tracking-tighter sm:text-4xl md:text-5xl section-title">
                Frequently Asked Questions
              </h2>
              <p className="mt-4 text-xl text-muted-foreground">Find answers to common questions about our platform</p>
            </div>

            <div className="max-w3xl mx-auto">
              <Accordion type="single" collapsible className="w-full">
                <AccordionItem value="item-1">
                  <AccordionTrigger className="text-left">How secure is my data on your platform?</AccordionTrigger>
                  <AccordionContent>
                    Your data is protected with AES-256 encryption, the industry standard for secure data storage. We
                    also implement multi-factor authentication, regular security audits, and follow best practices for
                    data protection. Our servers are hosted in secure facilities with 24/7 monitoring.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-2">
                  <AccordionTrigger className="text-left">
                    What happens if I miss a monthly life declaration?
                  </AccordionTrigger>
                  <AccordionContent>
                    If you miss a monthly life declaration, you'll receive multiple reminders via email and SMS. After a
                    grace period, if still unverified, your nominees will be notified. Your account remains secure, but
                    certain features may be temporarily restricted until verification is completed.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-3">
                  <AccordionTrigger className="text-left">How do I add or change nominees?</AccordionTrigger>
                  <AccordionContent>
                    You can add or change nominees through your account dashboard. Navigate to the "Nominees" section,
                    where you can add new nominees by providing their contact information and setting their access
                    levels. You can modify or remove existing nominees at any time. All changes to nominees require
                    additional verification for security purposes.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-4">
                  <AccordionTrigger className="text-left">
                    What types of assets can I upload to the platform?
                  </AccordionTrigger>
                  <AccordionContent>
                    You can upload various types of assets including financial documents (bank statements, investment
                    portfolios), legal documents (wills, trusts, power of attorney), property deeds, insurance policies,
                    digital asset information, and personal identification documents. All files are encrypted and
                    securely stored.
                  </AccordionContent>
                </AccordionItem>

                <AccordionItem value="item-5">
                  <AccordionTrigger className="text-left">What subscription plans do you offer?</AccordionTrigger>
                  <AccordionContent>
                    We offer several subscription tiers to meet different needs. Our Basic plan includes essential
                    features for individual users. The Premium plan adds additional storage and nominee options. Our
                    Family plan allows for multiple user profiles under one account. Business plans are also available
                    for organizations. All plans include our core security features and monthly verification system.
                  </AccordionContent>
                </AccordionItem>
              </Accordion>
            </div>
          </div>
        </section>

      </div>
      <div data-scroll-section>
        <Footer />
      </div>
    </div>
  )
}
